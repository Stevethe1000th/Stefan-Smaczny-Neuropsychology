This folder contains a few scripts I wrote that can be helpful when analyzing indirect measures of brain lesion data (e.g., disconnection maps, parcel-wise disconnection). 

For each file, there is a description of what it does at the beginning of the code.