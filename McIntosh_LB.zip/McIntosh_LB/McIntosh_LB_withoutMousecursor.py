''' Created by Stefan Smaczny, Christoph Sperber & Bianca de Haan

    for questions, contact stefan.smaczny@uni-tuebingen.de

    Additional thanks to:
    - Michele Svanera for code for drawing with the mouse at https://gitlab.pavlovia.org/rockNroll/demo_drawing
    - Peirce, JW (2007) PsychoPy - Psychophysics software in Python.
        Journal of Neuroscience Methods, 162(1-2), 8-13.
    - Peirce, JW (2009) Generating stimuli for neuroscience using PsychoPy.
        Frontiers in Neuroinformatics, 2:10. doi: 10.3389/neuro.11.010.2008

This is an implementation of the line bisection task as used by McIntosh and colleagues, e.g.:
    McIntosh, R. D., Schindler, I., Birchall, D., & Milner, A. D. (2005). Weights and measures: A new look at bisection behaviour in neglect. Cognitive Brain Research, 25(3), 833-850.
    McIntosh, R. D., Ietswaart, M., & Milner, A. D. (2017). Weight and see: Line bisection in neglect reliably measures the allocation of attention, but not the perception of length. Neuropsychologia, 106, 146-158.

preregister your studies for better science!


#!/usr/bin/env python
# -*- coding: utf-8 -*-
'''



from __future__ import absolute_import, division
from psychopy import locale_setup, sound, gui, visual, core, data, event, logging, clock
from psychopy.constants import (NOT_STARTED, STARTED, PLAYING, PAUSED,
                                STOPPED, FINISHED, PRESSED, RELEASED, FOREVER)
import numpy as np  # whole numpy lib is available, prepend 'np.'
from numpy import (sin, cos, tan, log, log10, pi, average,
                   sqrt, std, deg2rad, rad2deg, linspace, asarray)
from numpy.random import random, randint, normal, shuffle
import os  # handy system and path functions
import sys  # to get file system encoding

from psychopy.hardware import keyboard



your_screenwidth = 'Type your screenwidth in cm here'



# Ensure that relative paths start from the same directory as this script
_thisDir = os.path.dirname(os.path.abspath(__file__))
os.chdir(_thisDir)

Testing = False # set this to false if you ARE testing a participant
                 # Setting this to true is only useful for testing whether the calculation part works as it should etc
                 # This essentially skips a lot of waiting times to get through bisections quicker


'''
Some issues that might come up:

     - make sure the previous line can't be seen at the beginning of the next trial
           => This was addressed by adding a core.wait of
           exactly 0.5 (shorter won't work?) as first line of Starting Routine Wait

     - Why are my lines not being displayed at the correct length?
       => This can be solved with Monitor center

'''

# some initialisations and variables ----------------------------------------------------
responses = []
lineMids = []
lineTypes = []
sizeA = 8
sizeB = 12
sizeC = sizeB
sizeD = 16
midA = 0
midB = -2
midC = 2
midD = midA
amountStimuli = 32
thicknessLine = 0.2

# Ensure that relative paths start from the same directory as this script
_thisDir = os.path.dirname(os.path.abspath(__file__))
os.chdir(_thisDir)

# Store info about the experiment session
psychopyVersion = '3.1.3'
expName = 'McIntoshStandard'  # from the Builder filename that created this script
expInfo = {'participant': '', 'session': '001','screenwidth':your_screenwidth}
dlg = gui.DlgFromDict(dictionary=expInfo, sortKeys=False, title=expName)
if dlg.OK == False:
    core.quit()  # user pressed cancel
expInfo['date'] = data.getDateStr()  # add a simple timestamp
expInfo['expName'] = expName
expInfo['psychopyVersion'] = psychopyVersion

# Data file name stem = absolute path + name; later add .psyexp, .csv, .log, etc
filename = _thisDir + os.sep + u'data/%s_%s_%s' % (expInfo['participant'], expName, expInfo['date'])

# An ExperimentHandler isn't essential but helps with data saving
thisExp = data.ExperimentHandler(name=expName, version='',
    extraInfo=expInfo, runtimeInfo=None,
    originPath=_thisDir,
    savePickle=True, saveWideText=True,
    dataFileName=filename)
# save a log file for detail verbose info
logFile = logging.LogFile(filename+'.log', level=logging.EXP)
logging.console.setLevel(logging.WARNING)  # this outputs to the screen, not a file

endExpNow = False  # flag for 'escape' or other condition => quit the exp

# Start Code - component code to be run before the window creation

# Setup the Monitor in a way that does not rely on monitor centre, as this saves only to user-account, which created problems with students using different computers
from win32api import GetSystemMetrics
SCREENWIDTH = GetSystemMetrics(0)
SCREENHEIGHT = GetSystemMetrics(1)



from psychopy import visual, monitors
m = monitors.Monitor('testMonitor') #default monitor when opening Psychopy
m.setSizePix((SCREENWIDTH, SCREENHEIGHT)) #set resolution of monitor
m.setWidth(expInfo['screenwidth']) #set screen width in cm
m.setDistance(40) #set distance from eye to monitor in cm
m.saveMon() #save to monitor centre, which should then be updated
win = visual.Window(
    monitor=m,
    units='cm',
    blendMode='avg', useFBO=True,
    winType='pyglet', allowGUI=False, allowStencil=False,
    size=[SCREENWIDTH, SCREENHEIGHT], fullscr=True, screen=0,
    colorSpace='rgb', color=[1.000,1.000,1.000],
)

# store frame rate of monitor if we can measure it
expInfo['frameRate'] = win.getActualFrameRate()
if expInfo['frameRate'] != None:
    frameDur = 1.0 / round(expInfo['frameRate'])
else:
    frameDur = 1.0 / 60.0  # could not measure, so guess

# create a default keyboard (e.g. to check for escape)
defaultKeyboard = keyboard.Keyboard()


# Initialize components for Routine "Instr"

# if you want to change the language of the instructions just type
InstrClock = core.Clock()
text = visual.TextStim(win=win, name='text',
    text='In the following task you will be \npresented with individual horizontal lines. \nPlease indicate the middle of the line \n\nPress -space- to continue ',
    font='Arial',
    units='cm', pos=(0, 0), height=.75, wrapWidth=None, ori=0,
    color=[-1.000,-1.000,-1.000], colorSpace='rgb', opacity=1,
    languageStyle='LTR',
    depth=0.0);


# Initialize components for Routine "Example"
ExampleClock = core.Clock()
exampleText = visual.TextStim(win=win, name='exampleText',
    text='Here you can see an example of \na line that was bisected.\nPress the spacebar when you are ready.',
    font='Arial',
    units='cm', pos=(0, 6), height=.75, wrapWidth=None, ori=0,
    color='black', colorSpace='rgb', opacity=1,
    languageStyle='LTR',
    depth=0.0);
exampleLine = visual.Rect(
    win=win, name='exampleLine',
    width=(12, .2)[0], height=(.2, .2)[1],
    ori=0, pos=(0, 0),units='cm',
    lineWidth=0.2, lineColor=[-1.000,-1.000,-1.000], lineColorSpace='rgb',
    fillColor=[-1.000,-1.000,-1.000], fillColorSpace='rgb',
    opacity=1, depth=-2.0, interpolate=True)
exampleBisection = visual.Rect(
    win=win, name='exampleBisection',units='cm',
    width=(0.05, 3)[0], height=(0.05, 3)[1],
    ori=0, pos=(0, 0),
    lineWidth=1, lineColor=[-1.000,-1.000,-1.000], lineColorSpace='rgb',
    fillColor=[-1.000,-1.000,-1.000], fillColorSpace='rgb',
    opacity=1, depth=-3.0, interpolate=True)

#MouseCursor = visual.ImageStim(
#    win=win,
#    name='MouseCursor',
#    image=_thisDir+'\\MouseCursor.png', mask=None,
#    ori=0, pos=(0.25, -1.8), size=(0.5, 0.5),
#    color=[1,1,1], colorSpace='rgb', opacity=1,
#    flipHoriz=False, flipVert=False,
#    texRes=128, interpolate=True, depth=-4.0)

# Initialize components for Routine "fixation"
fixationClock = core.Clock()
fix = visual.Rect(
    win=win, name='fix',units='cm',
    width=(8, 1.5)[0], height=(8, 1.5)[1],
    ori=0, pos=(0, 5),
    lineWidth=1, lineColor=[-1.000,-1.000,-1.000], lineColorSpace='rgb',
    fillColor=[0.647,0.647,0.647], fillColorSpace='rgb',
    opacity=0.1, depth=0.0, interpolate=True)
mouse_2 = event.Mouse(win=win)
x, y = [None, None]
mouse_2.mouseClock = core.Clock()
bitteklicken = visual.TextStim(win=win, name='bitteklicken',
    text='[Bitte hier klicken]',
    font='Arial',
    units='cm', pos=(0, 5), height=1, wrapWidth=None, ori=0,
    color=[-1.000,-1.000,-1.000], colorSpace='rgb', opacity=1,
    languageStyle='LTR',
    depth=-2.0);

# Initialize components for Routine "wait"
waitClock = core.Clock()
polygon = visual.ShapeStim(
    win=win, name='polygon',
    vertices=[[-(0.5, 0.5)[0]/2.0,-(0.5, 0.5)[1]/2.0], [+(0.5, 0.5)[0]/2.0,-(0.5, 0.5)[1]/2.0], [0,(0.5, 0.5)[1]/2.0]],
    ori=0, pos=(0, 0),
    lineWidth=1, lineColor=[1,1,1], lineColorSpace='rgb',
    fillColor=[1,1,1], fillColorSpace='rgb',
    opacity=0, depth=0.0, interpolate=True)

# Initialize components for Routine "trial"
trialClock = core.Clock()
Empty_shapes = 100
mouse = event.Mouse(win=win)
x, y = [None, None]
mouse.mouseClock = core.Clock()
Line = visual.Rect(
    win=win, name='Line',units='cm',
    width=[1.0, 1.0][0], height=[1.0, 1.0][1],
    ori=0, pos=[0,0],
    lineWidth=1, lineColor=[-1.000,-1.000,-1.000], lineColorSpace='rgb',
    fillColor=[-1.000,-1.000,-1.000], fillColorSpace='rgb',
    opacity=1, depth=-1.0, interpolate=True)
lineWait = 2
if Testing == True:
    lineWait = 0



# Initialize components for Routine "Calculation"
CalculationClock = core.Clock()


# Initialize components for Routine "End"
EndClock = core.Clock()
text_2 = visual.TextStim(win=win, name='text_2',
    text='Vielen Dank für Ihre Teilnahme!\n\nSagen Sie bitte der Versuchsleitung bescheid',
    font='Arial',
    pos=(0, 0), height=1, wrapWidth=None, ori=0,
    color='black', colorSpace='rgb', opacity=1,
    languageStyle='LTR',
    depth=0.0);

# Create some handy timers
globalClock = core.Clock()  # to track the time since experiment started
routineTimer = core.CountdownTimer()  # to track time remaining of each (non-slip) routine


# ------Prepare to start Routine "Instr"-------
t = 0
InstrClock.reset()  # clock
frameN = -1
continueRoutine = True
# update component parameters for each repeat
key_resp = keyboard.Keyboard()
# keep track of which components have finished
InstrComponents = [text, key_resp]
for thisComponent in InstrComponents:
    thisComponent.tStart = None
    thisComponent.tStop = None
    thisComponent.tStartRefresh = None
    thisComponent.tStopRefresh = None
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED

# -------Start Routine "Instr"-------
while continueRoutine:
    # get current time
    t = InstrClock.getTime()
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame

    # *text* updates
    if t >= 0.0 and text.status == NOT_STARTED:
        # keep track of start time/frame for later
        text.tStart = t  # not accounting for scr refresh
        text.frameNStart = frameN  # exact frame index
        win.timeOnFlip(text, 'tStartRefresh')  # time at next scr refresh
        text.setAutoDraw(True)

    # *key_resp* updates
    if t >= 0.0 and key_resp.status == NOT_STARTED:
        # keep track of start time/frame for later
        key_resp.tStart = t  # not accounting for scr refresh
        key_resp.frameNStart = frameN  # exact frame index
        win.timeOnFlip(key_resp, 'tStartRefresh')  # time at next scr refresh
        key_resp.status = STARTED
        # keyboard checking is just starting
        win.callOnFlip(key_resp.clock.reset)  # t=0 on next screen flip
        key_resp.clearEvents(eventType='keyboard')
    if key_resp.status == STARTED:
        theseKeys = key_resp.getKeys(keyList=['space'], waitRelease=False)
        if len(theseKeys):
            theseKeys = theseKeys[0]  # at least one key was pressed

            # check for quit:
            if "escape" == theseKeys:
                endExpNow = True
#            key_resp.keys = theseKeys.name  # just the last key pressed
#            key_resp.rt = theseKeys.rt
            # a response ends the routine
            continueRoutine = False

    # check for quit (typically the Esc key)
    if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
        core.quit()

    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in InstrComponents:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished

    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# -------Ending Routine "Instr"-------
for thisComponent in InstrComponents:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
#thisExp.addData('text.started', text.tStartRefresh)
#thisExp.addData('text.stopped', text.tStopRefresh)
# check responses
if key_resp.keys in ['', [], None]:  # No response was made
    key_resp.keys = None
#thisExp.addData('key_resp.keys',key_resp.keys)
#if key_resp.keys != None:  # we had a response
#    thisExp.addData('key_resp.rt', key_resp.rt)
#thisExp.addData('key_resp.started', key_resp.tStartRefresh)
#thisExp.addData('key_resp.stopped', key_resp.tStopRefresh)
#thisExp.nextEntry()
# the Routine "Instr" was not non-slip safe, so reset the non-slip timer
routineTimer.reset()

# ------Prepare to start Routine "Example"-------
t = 0
ExampleClock.reset()  # clock
frameN = -1
continueRoutine = True
# update component parameters for each repeat
exampleResponse = keyboard.Keyboard()
# keep track of which components have finished
ExampleComponents = [exampleText, exampleResponse, exampleLine, exampleBisection]
for thisComponent in ExampleComponents:
    thisComponent.tStart = None
    thisComponent.tStop = None
    thisComponent.tStartRefresh = None
    thisComponent.tStopRefresh = None
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED

# -------Start Routine "Example"-------
while continueRoutine:
    # get current time
    t = ExampleClock.getTime()
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame

    # *exampleText* updates
    if t >= 0.0 and exampleText.status == NOT_STARTED:
        # keep track of start time/frame for later
        exampleText.tStart = t  # not accounting for scr refresh
        exampleText.frameNStart = frameN  # exact frame index
        win.timeOnFlip(exampleText, 'tStartRefresh')  # time at next scr refresh
        exampleText.setAutoDraw(True)

    # *exampleResponse* updates
    if t >= 0.0 and exampleResponse.status == NOT_STARTED:
        # keep track of start time/frame for later
        exampleResponse.tStart = t  # not accounting for scr refresh
        exampleResponse.frameNStart = frameN  # exact frame index
        win.timeOnFlip(exampleResponse, 'tStartRefresh')  # time at next scr refresh
        exampleResponse.status = STARTED
        # keyboard checking is just starting
        win.callOnFlip(exampleResponse.clock.reset)  # t=0 on next screen flip
        exampleResponse.clearEvents(eventType='keyboard')
    if exampleResponse.status == STARTED:
        theseKeys = exampleResponse.getKeys(keyList=['space'], waitRelease=False)
        if len(theseKeys):
            theseKeys = theseKeys[0]  # at least one key was pressed

            # check for quit:
            if "escape" == theseKeys:
                endExpNow = True
            exampleResponse.keys = theseKeys.name  # just the last key pressed
            exampleResponse.rt = theseKeys.rt
            # a response ends the routine
            continueRoutine = False

    # *exampleLine* updates
    if t >= 0.0 and exampleLine.status == NOT_STARTED:
        # keep track of start time/frame for later
        exampleLine.tStart = t  # not accounting for scr refresh
        exampleLine.frameNStart = frameN  # exact frame index
        win.timeOnFlip(exampleLine, 'tStartRefresh')  # time at next scr refresh
        exampleLine.setAutoDraw(True)

    # *exampleBisection* updates
    if t >= 0.0 and exampleBisection.status == NOT_STARTED:
        # keep track of start time/frame for later
        exampleBisection.tStart = t  # not accounting for scr refresh
        exampleBisection.frameNStart = frameN  # exact frame index
        win.timeOnFlip(exampleBisection, 'tStartRefresh')  # time at next scr refresh
        exampleBisection.setAutoDraw(True)

    # *MouseCursor* updates
#    if t >= 0.0 and MouseCursor.status == NOT_STARTED:
#        # keep track of start time/frame for later
#        MouseCursor.tStart = t  # not accounting for scr refresh
#        MouseCursor.frameNStart = frameN  # exact frame index
#        win.timeOnFlip(MouseCursor, 'tStartRefresh')  # time at next scr refresh
#        MouseCursor.setAutoDraw(True)

    # check for quit (typically the Esc key)
    if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
        core.quit()

    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in ExampleComponents:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished

    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# -------Ending Routine "Example"-------
for thisComponent in ExampleComponents:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
#thisExp.addData('exampleText.started', exampleText.tStartRefresh)
#thisExp.addData('exampleText.stopped', exampleText.tStopRefresh)
# check responses
if exampleResponse.keys in ['', [], None]:  # No response was made
    exampleResponse.keys = None
#thisExp.addData('exampleResponse.keys',exampleResponse.keys)
#if exampleResponse.keys != None:  # we had a response
#    thisExp.addData('exampleResponse.rt', exampleResponse.rt)
#thisExp.addData('exampleResponse.started', exampleResponse.tStartRefresh)
#thisExp.addData('exampleResponse.stopped', exampleResponse.tStopRefresh)
#thisExp.nextEntry()
#thisExp.addData('exampleLine.started', exampleLine.tStartRefresh)
#thisExp.addData('exampleLine.stopped', exampleLine.tStopRefresh)
#thisExp.addData('exampleBisection.started', exampleBisection.tStartRefresh)
#thisExp.addData('exampleBisection.stopped', exampleBisection.tStopRefresh)
#thisExp.addData('MouseCursor.started', MouseCursor.tStartRefresh)
#thisExp.addData('MouseCursor.stopped', MouseCursor.tStopRefresh)
# the Routine "Example" was not non-slip safe, so reset the non-slip timer
routineTimer.reset()

# set up handler to look after randomisation of conditions etc
trials = data.TrialHandler(nReps=1, method='random',
    extraInfo=expInfo, originPath=-1,
    trialList=data.importConditions('lines.xlsx'),
    seed=None, name='trials')
thisExp.addLoop(trials)  # add the loop to the experiment
thisTrial = trials.trialList[0]  # so we can initialise stimuli with some values
# abbreviate parameter names if possible (e.g. rgb = thisTrial.rgb)
if thisTrial != None:
    for paramName in thisTrial:
        exec('{} = thisTrial[paramName]'.format(paramName))

for thisTrial in trials:
    currentLoop = trials
    # abbreviate parameter names if possible (e.g. rgb = thisTrial.rgb)
    if thisTrial != None:
        for paramName in thisTrial:
            exec('{} = thisTrial[paramName]'.format(paramName))

    # ------Prepare to start Routine "fixation"-------
    t = 0
    fixationClock.reset()  # clock
    frameN = -1
    continueRoutine = True
    # update component parameters for each repeat
    # setup some python lists for storing info about the mouse_2
    mouse_2.x = []
    mouse_2.y = []
    mouse_2.leftButton = []
    mouse_2.midButton = []
    mouse_2.rightButton = []
    mouse_2.time = []
    mouse_2.clicked_name = []
    gotValidClick = False  # until a click is received
    # keep track of which components have finished
    fixationComponents = [fix, mouse_2, bitteklicken]
    for thisComponent in fixationComponents:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    startTime = fixationClock.getTime()
    # -------Start Routine "fixation"-------
    while continueRoutine:
        # get current time
        t = fixationClock.getTime()
        timedif = t - startTime
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame

        # check for quit (typically the Esc key)
        if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
            core.quit()

        # stop trial if time is over
        if timedif > 1:
            continueRoutine = False

        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in fixationComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished

        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()

    # -------Ending Routine "fixation"-------
    lastX = x
    lastY = y
    for thisComponent in fixationComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
#    trials.addData('fix.started', fix.tStartRefresh)
#    trials.addData('fix.stopped', fix.tStopRefresh)
    # store data for trials (TrialHandler)
    if len(mouse_2.x): trials.addData('mouse_2.x', mouse_2.x[0])
    if len(mouse_2.y): trials.addData('mouse_2.y', mouse_2.y[0])
#    if len(mouse_2.leftButton): trials.addData('mouse_2.leftButton', mouse_2.leftButton[0])
#    if len(mouse_2.midButton): trials.addData('mouse_2.midButton', mouse_2.midButton[0])
#    if len(mouse_2.rightButton): trials.addData('mouse_2.rightButton', mouse_2.rightButton[0])
    if len(mouse_2.time): trials.addData('mouse_2.time', mouse_2.time[0])
    if len(mouse_2.clicked_name): trials.addData('mouse_2.clicked_name', mouse_2.clicked_name[0])
#    trials.addData('mouse_2.started', mouse_2.tStart)
#    trials.addData('mouse_2.stopped', mouse_2.tStop)
#    trials.addData('bitteklicken.started', bitteklicken.tStartRefresh)
#    trials.addData('bitteklicken.stopped', bitteklicken.tStopRefresh)
    # the Routine "fixation" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()

    # ------Prepare to start Routine "wait"-------
    t = 0
    waitClock.reset()  # clock
    frameN = -1
    continueRoutine = True
    routineTimer.add(0.5)
    # update component parameters for each repeat
    # keep track of which components have finished
    waitComponents = [polygon]
    for thisComponent in waitComponents:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED

    # -------Start Routine "wait"-------
    core.wait(.5) # if this is gone or any shorter, you can always see the line of the previous trial
    while continueRoutine and routineTimer.getTime() > 0:
        # get current time
        t = waitClock.getTime()
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame

        # *polygon* updates
        if t >= 0.0 and polygon.status == NOT_STARTED:
            # keep track of start time/frame for later
            polygon.tStart = t  # not accounting for scr refresh
            polygon.frameNStart = frameN  # exact frame index
            win.timeOnFlip(polygon, 'tStartRefresh')  # time at next scr refresh
            polygon.setAutoDraw(True)
        frameRemains = 0.0 + 0.5- win.monitorFramePeriod * 0.75  # most of one frame period left
        if polygon.status == STARTED and t >= frameRemains:
            # keep track of stop time/frame for later
            polygon.tStop = t  # not accounting for scr refresh
            polygon.frameNStop = frameN  # exact frame index
            win.timeOnFlip(polygon, 'tStopRefresh')  # time at next scr refresh
            polygon.setAutoDraw(False)

        # check for quit (typically the Esc key)
        if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
            core.quit()

        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in waitComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished

        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()

    # -------Ending Routine "wait"-------
    for thisComponent in waitComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
#    trials.addData('polygon.started', polygon.tStartRefresh)
#    trials.addData('polygon.stopped', polygon.tStopRefresh)

    # ------Prepare to start Routine "trial"-------
    t = 0
    gotXVal = False
    trialClock.reset()  # clock
    frameN = -1
    continueRoutine = True
    # update component parameters for each repeat
    polygon_vertex = [(0,0)]
    polygon_list = []
    for i in range(Empty_shapes):
        polygon_list.append(visual.ShapeStim(win, vertices=polygon_vertex,
                                         fillColor=None, lineWidth=5, lineColor='black'))

    first_iteration = True
    indx_shape = 0      # How many I draw so far
    before_left_button = False
    waitTimer = False

    # setup some python lists for storing info about the mouse
    mouse.x = [lastX]
    mouse.y = [lastY]
    lineCrossed = False
    mouse.leftButton = []
    mouse.midButton = []
    mouse.rightButton = []
    mouse.time = []
    mouse.clicked_name = []
    gotValidClick = False  # until a click is received
    mouse.mouseClock.reset()
    Line.setPos((pos, 0))
    Line.setSize((size,thicknessLine))
    # keep track of which components have finished
    trialComponents = [mouse, Line]
    for thisComponent in trialComponents:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED

    # -------Start Routine "trial"-------
    while continueRoutine:
        # get current time
        t = trialClock.getTime()
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)

        # update/draw components on each frame ------------------

        # I work on this trace
        polygon = polygon_list[indx_shape]

         # Get the current mouse position and state
        mouse_position = mouse.getPos()
        left_button, middle_button, right_button = mouse.getPressed()

        # If the left button is pressed, start drawing
        if left_button:

            # Initialise polygon_vertex
            if first_iteration == True:
                polygon_vertex = []
                first_iteration = False
                before_left_button = True

            # Update
            polygon_vertex.append(mouse_position)
            polygon.vertices = polygon_vertex

        else:
            # Did the partecipant stop drawing?
            if before_left_button:
                before_left_button = False
                first_iteration = True
                indx_shape += 1

        # Draw every polygon done so far
        for i_pol in range(indx_shape+1):
            polygon_list[i_pol].draw()
        
        # *mouse* updates -----------------------------------------
        if t >= 0.0 and mouse.status == NOT_STARTED:
            # keep track of start time/frame for later
            mouse.tStart = t  # not accounting for scr refresh
            mouse.frameNStart = frameN  # exact frame index
            win.timeOnFlip(mouse, 'tStartRefresh')  # time at next scr refresh
            mouse.status = STARTED
            prevButtonState = [0, 0, 0]  # if now button is down we will treat as 'new' click

        if mouse.status == STARTED:  # only update if started and not finished!
            x, y = mouse.getPos()
            mouse.x.append(x)
            mouse.y.append(y)

            buttons = mouse.getPressed()
            mouse.leftButton.append(buttons[0])
            mouse.midButton.append(buttons[1])
            mouse.rightButton.append(buttons[2])
            mouse.time.append(mouse.mouseClock.getTime())
            buttons = mouse.getPressed()
            xAxisCrossed = False
            if sum(buttons) > 0:  # state changed to a new click
                # check if the mouse was inside our 'clickable' objects
                gotValidClick = False
                if y != lastY:
                    if y == 0:
                        CrossingX = x
                        xAxisCrossed = True
                    elif ((y<0) and (lastY>0) or ((y>0) and (lastY<0))):
                        CrossingX = ((x-lastX)*lastY)/(lastY-y) + lastX
                        xAxisCrossed = True
                        print(CrossingX)
                    if xAxisCrossed == True:
                        if ((CrossingX > pos-(size/2)) and CrossingX < pos+(size/2)):
                            gotValidClick=True
                            bisectionX =x
                            lineType = type
                            lineTypes.append(lineType)
                            lineMid = pos
                            lineMids.append(lineMid)
                            responses.append(x)
                if gotValidClick:  # abort routine on response
                    waitTimer = True
                    waitTimer = t
                    continueRoutine = False

# *Line* updates
        if t >= 0.0 and Line.status == NOT_STARTED:
            # keep track of start time/frame for later
            Line.tStart = t  # not accounting for scr refresh
            Line.frameNStart = frameN  # exact frame index
            win.timeOnFlip(Line, 'tStartRefresh')  # time at next scr refresh
            Line.setAutoDraw(True)

        # check for quit (typically the Esc key)
        if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
            core.quit()
        lastX = x
        lastY = y
        currentTime = t
        # check if all components have finished
        if waitTimer:
            if (currentTime - waitTimer)>lineWait:  # a component has requested a forced-end of Routine
                break

        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in trialComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished

        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()

    # -------Ending Routine "trial"-------


    first_iteration = True
    indx_shape = 0      # How many I draw so far
    before_left_button = False
    for thisComponent in trialComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    # store data for trials (TrialHandler)
    #trials.addData('mouse.x', mouse.x)
    #trials.addData('mouse.y', mouse.y)
    #trials.addData('mouse.leftButton', mouse.leftButton)
    #trials.addData('mouse.midButton', mouse.midButton)
    #trials.addData('mouse.rightButton', mouse.rightButton)
    #trials.addData('mouse.time', mouse.time)
    #trials.addData('mouse.clicked_name', mouse.clicked_name)
    #trials.addData('mouse.started', mouse.tStart)
    #trials.addData('mouse.stopped', mouse.tStop)
    #trials.addData('Line.started', Line.tStartRefresh)
    #trials.addData('Line.stopped', Line.tStopRefresh)
    #trials.addData('Bisection X' , bisectionX)
    # the Routine "trial" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    thisExp.nextEntry()

# completed 1 repeats of 'trials'



# ------Prepare to start Routine "Calculation"-------
t = 0
CalculationClock.reset()  # clock
frameN = -1
continueRoutine = True
# update component parameters for each repeat
# keep track of which components have finished
CalculationComponents = []
for thisComponent in CalculationComponents:
    thisComponent.tStart = None
    thisComponent.tStop = None
    thisComponent.tStartRefresh = None
    thisComponent.tStopRefresh = None
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED
ListAC = []
ListBD = []
ListCD = []
ListAB = []
ListA = []
ListB = []
ListC = []
ListD = []

# -------Start Routine "Calculation"-------
while continueRoutine:
    # get current time
    t = CalculationClock.getTime()
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)

    # EWB
    for i in range(1,amountStimuli+1):
        if lineTypes[i-1] == 'A':
            ListAC.append(responses[i-1])
            ListAB.append(responses[i-1])
        elif lineTypes[i-1]== 'B':
            ListAB.append(responses[i-1])
            ListBD.append(responses[i-1])
        elif lineTypes[i-1] == 'C':
            ListAC.append(responses[i-1])
            ListCD.append(responses[i-1])
        else:
            ListBD.append(responses[i-1])
            ListCD.append(responses[i-1])
    
    # means
    def Average(lst):
        return sum(lst)/len(lst)
    meanAC = Average(ListAC)
    meanAB = Average(ListAB)
    meanCD = Average(ListCD)
    meanBD = Average(ListBD)


    # calculate dPL and dPR
    dPL = (meanAC - meanBD)/4
    dPR = (meanCD - meanAB)/4

    # EWB & EWS
    EWB = dPR-dPL
    EWS = dPR+dPL

    # classic LB
    for i in range(1,amountStimuli):
        if lineTypes[i-1] == 'A':
            ListA.append(responses[i-1])
        elif lineTypes[i-1] == 'B':
            ListB.append(responses[i-1])
        elif lineTypes[i-1] == 'C':
            ListC.append(responses[i-1])
        else:
            ListD.append(responses[i-1])

    MeanA = Average(ListA)
    MeanB = Average(ListB)
    MeanC = Average(ListC)
    MeanD = Average(ListD)

    # get the deviations in percentages according to Schenkenberg 1980
    def deviation(size,lst,mid):
        return (((((size/2) + Average(lst))-mid - (size/2))/(size/2))*100)
    deviationA = deviation(sizeA,ListA,midA)
    deviationB = deviation(sizeB,ListB,midB)
    deviationC = deviation(sizeC,ListC,midC)
    deviationD = deviation(sizeD,ListD,midD)
    deviations = Average([deviationA,deviationB,deviationC,deviationD])
    info1 = [meanAC, meanAB, meanCD, meanBD]
    info2 = [dPL, dPR, EWB,EWS]
    info3 = [MeanA,MeanB,MeanC,MeanD]
    info4 = [deviationA,deviationB,deviationC,deviationD,deviations]
    trials.addData('mean AC', meanAC) # just do each one seperately
    trials.addData('meanAB',meanAB)
    trials.addData('meanCD',meanCD)
    trials.addData('meanBD',meanBD)
    trials.addData('dPL',dPL)
    trials.addData('dPR',dPR)
    trials.addData('EWB',EWB)
    trials.addData('EWS',EWS)
    trials.addData('meanA',MeanA)
    trials.addData('meanB',MeanB)
    trials.addData('meanC',MeanC)
    trials.addData('meanD',MeanD)
    trials.addData('mean deviation A',deviationA)
    trials.addData('mean deviation B',deviationB)
    trials.addData('mean deviation C',deviationC)
    trials.addData('mean deviation D', deviationD)
    trials.addData('mean deviation overall', deviations)

    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in CalculationComponents:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished

    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# -------Ending Routine "Calculation"-------
for thisComponent in CalculationComponents:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
# the Routine "Calculation" was not non-slip safe, so reset the non-slip timer
routineTimer.reset()

# Flip one final time so any remaining win.callOnFlip()
# and win.timeOnFlip() tasks get executed before quitting
win.flip()

# these shouldn't be strictly necessary (should auto-save)
thisExp.saveAsWideText(filename+'.csv')
thisExp.saveAsPickle(filename)
logging.flush()
# make sure everything is closed down
thisExp.abort()  # or data files will save again on exit
win.close()
core.quit()



# ------Prepare to start Routine "End"-------
t = 0
EndClock.reset()  # clock
frameN = -1
continueRoutine = True
# update component parameters for each repeat
key_resp_2 = keyboard.Keyboard()
# keep track of which components have finished
EndComponents = [text_2, key_resp_2]
for thisComponent in EndComponents:
    thisComponent.tStart = None
    thisComponent.tStop = None
    thisComponent.tStartRefresh = None
    thisComponent.tStopRefresh = None
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED

# -------Start Routine "End"-------
while continueRoutine:
    # get current time
    t = EndClock.getTime()
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame

    # *text_2* updates
    if t >= 0.0 and text_2.status == NOT_STARTED:
        # keep track of start time/frame for later
        text_2.tStart = t  # not accounting for scr refresh
        text_2.frameNStart = frameN  # exact frame index
        win.timeOnFlip(text_2, 'tStartRefresh')  # time at next scr refresh
        text_2.setAutoDraw(True)

    # *key_resp_2* updates
    if t >= 0.0 and key_resp_2.status == NOT_STARTED:
        # keep track of start time/frame for later
        key_resp_2.tStart = t  # not accounting for scr refresh
        key_resp_2.frameNStart = frameN  # exact frame index
        win.timeOnFlip(key_resp_2, 'tStartRefresh')  # time at next scr refresh
        key_resp_2.status = STARTED
        # keyboard checking is just starting
        win.callOnFlip(key_resp_2.clock.reset)  # t=0 on next screen flip
        key_resp_2.clearEvents(eventType='keyboard')
    if key_resp_2.status == STARTED:
        theseKeys = key_resp_2.getKeys(keyList=['space'], waitRelease=False)
        if len(theseKeys):
            theseKeys = theseKeys[0]  # at least one key was pressed

            # check for quit:
            if "escape" == theseKeys:
                endExpNow = True
            key_resp_2.keys = theseKeys.name  # just the last key pressed
            key_resp_2.rt = theseKeys.rt
            # a response ends the routine
            continueRoutine = False

    # check for quit (typically the Esc key)
    if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
        core.quit()

    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in EndComponents:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished

    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# -------Ending Routine "End"-------
for thisComponent in EndComponents:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
#thisExp.addData('text_2.started', text_2.tStartRefresh)
#thisExp.addData('text_2.stopped', text_2.tStopRefresh)
# check responses
if key_resp_2.keys in ['', [], None]:  # No response was made
    key_resp_2.keys = None
#thisExp.addData('key_resp_2.keys',key_resp_2.keys)
if key_resp_2.keys != None:  # we had a response
    thisExp.addData('key_resp_2.rt', key_resp_2.rt)
#thisExp.addData('key_resp_2.started', key_resp_2.tStartRefresh)
#thisExp.addData('key_resp_2.stopped', key_resp_2.tStopRefresh)
thisExp.nextEntry()
# the Routine "End" was not non-slip safe, so reset the non-slip timer
routineTimer.reset()

# Flip one final time so any remaining win.callOnFlip()
# and win.timeOnFlip() tasks get executed before quitting
win.flip()

# these shouldn't be strictly necessary (should auto-save)
thisExp.saveAsWideText(filename+'.csv')
thisExp.saveAsPickle(filename)
logging.flush()
# make sure everything is closed down
thisExp.abort()  # or data files will save again on exit
win.close()
core.quit()
